$p=Get-Process
$l=$p.length
$mayor=""
$tiempo=0
for ($i=0; $i -lt $l; $i++){
	if ( $p[$i].CPU -gt $tiempo ){
	$mayor=$p[$i]
	$tiempo=$p[$i].CPU
}
}
write-host "El proceso que mas utiliza la CPU es: "$mayor.Name 