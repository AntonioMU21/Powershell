$texto=get-content C:\Users\Alumno\Desktop\ExamenPW\procesos.txt
$l=$texto.length
for ($i=0;$i -lt $l; $i++){
	Start-Process $texto[$i]
}